<?php
   class Redux_Customizer_Control_image_select extends Redux_Customizer_Control {
     public $type = "redux-image_select";
   }